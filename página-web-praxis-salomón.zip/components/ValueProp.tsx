
import React from 'react';
import { SectionId } from '../types';

export const ValueProp: React.FC = () => {
  return (
    <section id={SectionId.Approach} className="py-24 bg-white">
      <div className="max-w-4xl mx-auto px-6 text-center">
        <span className="text-[#C5A059] tracking-[0.3em] uppercase text-xs mb-4 block">Nuestra Propuesta</span>
        <h2 className="text-4xl md:text-5xl font-serif mb-10">Praxis Salomón: Sabiduría en la Acción</h2>
        <p className="text-lg text-gray-600 mb-16 leading-relaxed">
          No vendemos fórmulas mágicas ni plantillas genéricas. Proporcionamos el espacio y el método para que la alta dirección recupere su capacidad de juicio. Ordenamos el caos para que la dirección sea obvia.
        </p>
        
        <div className="grid md:grid-cols-3 gap-12 text-left">
          <div>
            <div className="text-3xl font-serif mb-4">01.</div>
            <h4 className="font-bold uppercase tracking-widest text-sm mb-3">Orden antes que ruido</h4>
            <p className="text-sm text-gray-500">Eliminamos lo superfluo para que solo quede lo fundamental.</p>
          </div>
          <div>
            <div className="text-3xl font-serif mb-4">02.</div>
            <h4 className="font-bold uppercase tracking-widest text-sm mb-3">Dirección antes que acción</h4>
            <p className="text-sm text-gray-500">Aseguramos que cada paso dado tenga un sentido estratégico claro.</p>
          </div>
          <div>
            <div className="text-3xl font-serif mb-4">03.</div>
            <h4 className="font-bold uppercase tracking-widest text-sm mb-3">Criterio sobre modas</h4>
            <p className="text-sm text-gray-500">Priorizamos los principios inmutables de los negocios sobre el hype del momento.</p>
          </div>
        </div>
      </div>
    </section>
  );
};
