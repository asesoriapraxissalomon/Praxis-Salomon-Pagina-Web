
import React from 'react';
import { SERVICES } from '../constants';
import { SectionId } from '../types';

export const Services: React.FC = () => {
  return (
    <section id={SectionId.Services} className="py-24 bg-[#F5F5F0]">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-6">
          <div className="max-w-2xl">
            <span className="text-[#C5A059] tracking-[0.3em] uppercase text-xs mb-4 block">Nuestros Servicios</span>
            <h2 className="text-4xl md:text-5xl font-serif">Intervenciones precisas para resultados duraderos.</h2>
          </div>
          <a href={`#${SectionId.Contact}`} className="text-sm tracking-widest uppercase border-b border-black py-2 hover:text-[#C5A059] hover:border-[#C5A059] transition-all">
            Solicitar dossier completo
          </a>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {SERVICES.map((service) => (
            <div key={service.id} className="bg-white p-10 border border-black/5 hover:border-[#C5A059] transition-all group flex flex-col h-full">
              <div className="text-[#C5A059] mb-8 group-hover:scale-110 transition-transform duration-300">
                {service.icon}
              </div>
              <h3 className="font-serif text-2xl mb-4">{service.title}</h3>
              <p className="text-sm text-gray-500 leading-relaxed mb-8 flex-grow">
                {service.description}
              </p>
              <div className="pt-4 border-t border-gray-100 mt-auto opacity-0 group-hover:opacity-100 transition-opacity">
                <span className="text-[10px] uppercase tracking-widest font-bold">Consultar disponibilidad</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
