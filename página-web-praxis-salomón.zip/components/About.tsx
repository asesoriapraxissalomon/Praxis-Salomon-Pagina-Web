
import React from 'react';
import { SectionId } from '../types';

export const About: React.FC = () => {
  return (
    <section id={SectionId.Founder} className="py-24 bg-white overflow-hidden">
      <div className="max-w-4xl mx-auto px-6">
        <div className="text-center mb-16">
          <span className="text-[#C5A059] tracking-[0.3em] uppercase text-[10px] font-bold mb-6 block">Sobre la Dirección</span>
          <h2 className="text-4xl md:text-5xl font-serif mb-10 leading-tight">Una visión crítica basada en la experiencia.</h2>
        </div>
        
        <div className="max-w-2xl mx-auto">
          <div className="space-y-8 text-gray-700 font-light leading-relaxed text-lg">
            <p>
              Fundé Praxis Salomón con una premisa clara: el mayor riesgo de una empresa no es la falta de tecnología, sino la falta de claridad en el pensamiento.
            </p>
            <p>
              He trabajado de cerca con emprendedores, equipos y proyectos en etapas clave, observando un patrón constante: organizaciones que avanzan sin dirección clara tienden a dispersarse, mientras que aquellas que piensan bien antes de actuar multiplican su impacto.
            </p>
            <p>
              Mi papel es ser ese interlocutor estratégico que cuestiona lo obvio, ordena lo complejo y ayuda a definir una dirección clara y sostenible antes de ejecutar.
            </p>
            
            <div className="pt-12 text-center">
              <blockquote className="italic font-serif text-2xl text-black mb-6 relative inline-block">
                <span className="absolute -top-6 -left-8 text-6xl text-[#C5A059] opacity-20 font-serif">“</span>
                La mayoría de los problemas de negocio son, en realidad, problemas de falta de criterio.
                <span className="absolute -bottom-10 -right-8 text-6xl text-[#C5A059] opacity-20 font-serif">”</span>
              </blockquote>
              <div className="mt-8 flex flex-col items-center">
                <span className="w-12 h-px bg-[#C5A059] mb-4"></span>
                <p className="font-bold uppercase tracking-[0.2em] text-[11px] text-black">
                  Eugenio Mayo
                </p>
                <p className="text-[9px] uppercase tracking-[0.3em] text-[#C5A059] mt-1">Fundador de Praxis</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
