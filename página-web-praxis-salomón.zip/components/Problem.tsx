
import React from 'react';
import { SectionId } from '../types';

export const Problem: React.FC = () => {
  return (
    <section id={SectionId.Problem} className="py-24 bg-praxis-dark text-praxis-light">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-2 gap-20 items-center">
          <div>
            <span className="text-[#C5A059] tracking-[0.3em] uppercase text-xs mb-4 block">El contexto actual</span>
            <h2 className="text-4xl md:text-5xl font-serif mb-8 leading-snug">
              La dispersión es el enemigo silencioso de la rentabilidad.
            </h2>
            <div className="space-y-6 text-gray-400 font-light leading-relaxed">
              <p>
                Las organizaciones modernas no sufren por falta de información, sino por exceso de ruido. La velocidad ha sustituido a la dirección, y el "hacer" ha canibalizado al "pensar".
              </p>
              <p>
                El resultado son decisiones reactivas, equipos agotados en lo urgente y una pérdida progresiva de la ventaja competitiva real: el criterio propio.
              </p>
            </div>
          </div>
          <div className="grid grid-cols-1 gap-8">
            <div className="p-8 border border-white/10 hover:border-[#C5A059]/50 transition-colors bg-white/5">
              <h3 className="font-serif text-xl mb-3 text-[#C5A059]">Confusión</h3>
              <p className="text-sm text-gray-400">Multitud de objetivos sin una jerarquía clara, dispersando recursos críticos.</p>
            </div>
            <div className="p-8 border border-white/10 hover:border-[#C5A059]/50 transition-colors bg-white/5">
              <h3 className="font-serif text-xl mb-3 text-[#C5A059]">Inercia</h3>
              <p className="text-sm text-gray-400">Seguir modas tecnológicas o metodológicas sin validar si resuelven el problema raíz.</p>
            </div>
            <div className="p-8 border border-white/10 hover:border-[#C5A059]/50 transition-colors bg-white/5">
              <h3 className="font-serif text-xl mb-3 text-[#C5A059]">Miedo al vacío</h3>
              <p className="text-sm text-gray-400">Decidir rápido para calmar la ansiedad, en lugar de decidir bien para asegurar el futuro.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
