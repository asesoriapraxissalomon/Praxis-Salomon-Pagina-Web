
import React, { useState } from 'react';
import { generateDiagnosticInsight } from '../services/geminiService';

export const DiagnosticTool: React.FC = () => {
  const [input, setInput] = useState('');
  const [result, setResult] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanInput = input.trim();
    if (!cleanInput || loading) return;

    setLoading(true);
    setResult(null);
    
    try {
      const insight = await generateDiagnosticInsight(cleanInput);
      setResult(insight);
    } catch (err) {
      console.error("Diagnostic UI Error:", err);
      setResult("Hubo un problema al conectar con el motor de diagnóstico. Por favor, inténtelo de nuevo más tarde.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-praxis-gray p-8 md:p-12 text-white border border-white/10 shadow-2xl transition-all duration-500">
      <h3 className="font-serif text-2xl mb-6">Ponga a prueba su dilema estratégico</h3>
      <p className="text-gray-400 text-sm mb-8">
        Describa brevemente un desafío de dirección que enfrenta actualmente. Nuestro sistema de análisis basado en principios de Praxis le proporcionará un primer ángulo de visión.
      </p>
      
      {!result ? (
        <form onSubmit={handleSubmit} className="space-y-6">
          <textarea 
            className="w-full bg-white/5 border border-white/10 p-4 text-sm focus:border-[#C5A059] outline-none transition-colors min-h-[120px] resize-none"
            placeholder="Ej: 'Mi equipo está ejecutando bien pero siento que hemos perdido el foco estratégico en el largo plazo...'"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            disabled={loading}
          />
          <button 
            type="submit"
            disabled={loading || !input.trim()}
            className="w-full bg-[#C5A059] text-white py-4 text-xs tracking-widest uppercase font-bold hover:bg-[#b08e4d] transition-all disabled:opacity-30 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {loading ? (
              <>
                <svg className="animate-spin h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Analizando Criterios...
              </>
            ) : 'Obtener Insight Estratégico'}
          </button>
        </form>
      ) : (
        <div className="animate-fade-in">
          <div className="bg-white/5 p-6 border-l-2 border-[#C5A059] mb-8">
            <p className="text-gray-300 italic text-sm leading-relaxed whitespace-pre-wrap">
              {result}
            </p>
          </div>
          <button 
            onClick={() => {setResult(null); setInput('');}}
            className="text-xs tracking-widest uppercase text-[#C5A059] border-b border-[#C5A059] pb-1 hover:text-white hover:border-white transition-all"
          >
            Realizar otro análisis
          </button>
        </div>
      )}
    </div>
  );
};
