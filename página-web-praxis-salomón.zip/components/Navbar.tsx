
import React, { useState, useEffect } from 'react';
import { NAV_ITEMS } from '../constants';
import { SectionId } from '../types';

export const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`fixed w-full z-50 transition-all duration-300 ${isScrolled ? 'bg-white/95 backdrop-blur-md shadow-sm py-4' : 'bg-transparent py-6'}`}>
      <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
        <a href={`#${SectionId.Home}`} className="flex flex-col">
          <span className="text-xl font-serif tracking-widest font-bold uppercase">Praxis Salomón</span>
          <span className="text-[10px] tracking-[0.3em] uppercase opacity-60">Consultoría de Dirección</span>
        </a>

        <div className="hidden md:flex space-x-10 items-center">
          {NAV_ITEMS.map((item) => (
            <a 
              key={item.href} 
              href={item.href} 
              className="text-sm tracking-widest uppercase hover:text-[#C5A059] transition-colors"
            >
              {item.label}
            </a>
          ))}
          <a 
            href={`#${SectionId.Contact}`}
            className="px-6 py-2 border border-black text-sm uppercase tracking-widest hover:bg-black hover:text-white transition-all"
          >
            Diagnóstico
          </a>
        </div>
      </div>
    </nav>
  );
};
