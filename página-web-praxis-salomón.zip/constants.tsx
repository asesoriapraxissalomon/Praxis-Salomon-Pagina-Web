
import React from 'react';
import { NavItem, Service, SectionId } from './types';

export const NAV_ITEMS: NavItem[] = [
  { label: 'El Ruido', href: `#${SectionId.Problem}` },
  { label: 'Enfoque', href: `#${SectionId.Approach}` },
  { label: 'Servicios', href: `#${SectionId.Services}` },
  { label: 'Sobre Praxis', href: `#${SectionId.Founder}` },
];

export const SERVICES: Service[] = [
  {
    id: 'diagnostico',
    title: 'Diagnóstico Estratégico',
    description: 'Identificación de cuellos de botella intelectuales y operativos. Una radiografía sin filtros sobre la situación real de su dirección.',
    icon: (
      <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
      </svg>
    ),
  },
  {
    id: 'direccion',
    title: 'Acompañamiento en Dirección',
    description: 'Diseño de la hoja de ruta. Transformamos la intención en dirección clara, priorizando lo fundamental sobre lo urgente.',
    icon: (
      <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
      </svg>
    ),
  },
  {
    id: 'ejecucion',
    title: 'Ejecución Guiada',
    description: 'Soporte táctico en la implementación de decisiones complejas. Aseguramos que el criterio se mantenga firme durante el proceso.',
    icon: (
      <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" />
      </svg>
    ),
  },
  {
    id: 'seguimiento',
    title: 'Consejo y Seguimiento',
    description: 'Revisiones periódicas de alta frecuencia para ajustar el rumbo. Un socio externo con visión crítica y objetiva.',
    icon: (
      <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
      </svg>
    ),
  },
];
