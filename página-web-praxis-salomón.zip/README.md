
# Praxis Salomón - Despliegue en GitHub

Sigue estos pasos para activar tu web profesional:

### 1. Hacer el repositorio Público (Opcional pero recomendado)
GitHub Pages es gratuito para repositorios **Públicos**.
- Ve a **Settings** > **General**.
- Baja hasta el final (**Danger Zone**).
- Haz clic en **Change visibility** y selecciona **Make public**.

### 2. Configurar la Clave de Inteligencia Artificial (API KEY)
Para que el diagnóstico funcione:
- Ve a **Settings** > **Secrets and variables** > **Actions**.
- Haz clic en **New repository secret**.
- Nombre: `API_KEY`
- Valor: (Pega aquí tu clave de Google Gemini)
- Haz clic en **Add secret**.

### 3. Activar Permisos de Escritura
Para que GitHub pueda crear la web:
- Ve a **Settings** > **Actions** > **General**.
- Baja hasta **Workflow permissions**.
- Selecciona **Read and write permissions**.
- Haz clic en **Save**.

### 4. Subir todos los archivos
Asegúrate de subir **todos** los archivos manteniendo la estructura de carpetas:
- `components/`
- `services/`
- `index.html`
- `package.json`
- etc.

### 5. Activar la URL
- Ve a **Settings** > **Pages**.
- En **Branch**, elige `gh-pages` y la carpeta `/(root)`.
- ¡Tu web estará lista en el enlace que aparezca arriba!
