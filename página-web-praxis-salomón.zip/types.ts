import React from 'react';

export interface Service {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
}

export interface NavItem {
  label: string;
  href: string;
}

export enum SectionId {
  Home = 'inicio',
  Problem = 'el-ruido',
  Approach = 'enfoque',
  Services = 'servicios',
  Founder = 'quienes-somos',
  Contact = 'contacto'
}