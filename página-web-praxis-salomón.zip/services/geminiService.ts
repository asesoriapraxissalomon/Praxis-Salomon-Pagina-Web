import { GoogleGenAI } from "@google/genai";

export const generateDiagnosticInsight = async (businessContext: string): Promise<string> => {
  try {
    // Inicialización dentro de la función para asegurar acceso al entorno actual
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    
    // Fix: Use 'gemini-3-pro-preview' for advanced reasoning/strategic tasks and move role-playing to systemInstruction
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: `Dilema estratégico: "${businessContext}"`,
      config: {
        systemInstruction: `Actúa como un consultor estratégico de Praxis Salomón. 
Proporciona un insight breve (máximo 3 párrafos), sobrio, profundo y profesional que invite a la reflexión estratégica. 
Evita el lenguaje motivacional. Céntrate en el "orden antes que ruido" y "dirección antes que acción".
Termina con una pregunta que cuestione su modelo mental actual.`,
        temperature: 0.6,
        topP: 0.9,
      }
    });

    // Fix: Access .text as a property, not a method, as per SDK guidelines
    if (!response || !response.text) {
      throw new Error("Respuesta vacía del modelo");
    }

    return response.text;
  } catch (error) {
    console.error("Gemini Service Error:", error);
    return "No hemos podido procesar su dilema en este momento debido a un error técnico. Por favor, reflexione sobre si el problema actual es síntoma de una falta de dirección clara y contáctenos directamente.";
  }
};
